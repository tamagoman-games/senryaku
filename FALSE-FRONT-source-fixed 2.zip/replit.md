# FALSE FRONT

日本語対応の戦術グリッドゲーム。計画フェーズで行動を予約し、敵AIと交戦しながら任務目標と脱出を目指します。

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API server
- `pnpm --filter @workspace/false-front run dev` — web client (managed workflow)
- `pnpm --filter @workspace/false-front run typecheck` — game client typecheck
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- No database or third-party integration is required for the current game.
- Cooperative room state is held in API server memory; active rooms are lost if the server restarts.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Realtime: room polling and version-checked state snapshots
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/false-front/src/game/engine.ts` — grid, visibility, orders, combat, economy, reinforcements, and round resolution
- `artifacts/false-front/src/pages/` — title, room lobby, and tactical game screens
- `artifacts/api-server/src/routes/games.ts` — cooperative rooms, state synchronization, and team communication
- `lib/api-spec/openapi.yaml` — source of truth for generated room API types

## Architecture decisions

- Solo missions keep their game state in the browser; co-op missions share JSON snapshots through the API.
- Co-op room updates use a version check so simultaneous writes fail clearly instead of silently overwriting each other.
- Room and chat state is process-local and intentionally requires a single API server instance.
- The current online mode is two-player co-op; the client simulation is not a server-authoritative competitive PvP engine.

## Product

Players can run a solo mission or create/join a two-player co-op room, choose one of six roles, queue tactical actions, fight NPC guards, collect supplies, purchase equipment, hire delayed reinforcements, use team chat, secure a data relay, and extract.

## User preferences

The game and UI are Japanese-first and should remain usable on phones as well as desktop browsers.

## Gotchas

- Change `lib/api-spec/openapi.yaml` first and run codegen before consuming API changes in the app.
- Restart the API workflow after server changes and the web workflow after client or build changes.
- Publishing the API server as multiple instances would split in-memory rooms and break co-op synchronization.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
