FALSE FRONT — ソースコード一式

このZIPには、FALSE FRONTのフロントエンド、協力プレイ用API、API仕様・生成クライアント、pnpmワークスペース設定を含みます。node_modules、Replitのキャッシュ／内部データ、ビルド生成物は含みません。

動作環境
- Node.js 24
- pnpm
- 依存パッケージを取得するネットワーク接続

セットアップ
1. ZIPを展開します。
2. 展開先で `pnpm install` を実行します。
3. ソロ作戦は `pnpm --filter @workspace/false-front run dev` でフロントエンドを起動して遊べます。
4. 2人協力プレイにはAPIサーバーとPostgreSQLが必要です。`DATABASE_URL` を設定してから `pnpm --filter @workspace/api-server run dev` を別ターミナルで起動してください。
5. Replit以外で協力プレイを動かす場合は、フロントエンドの `/api` リクエストをAPIサーバーへ転送するリバースプロキシも設定してください。

オンラインルームはAPIサーバーのメモリ上に保持され、サーバー再起動で消えます。このソースZIPには環境変数の値や認証情報は含まれていません。
