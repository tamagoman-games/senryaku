import { Router, type IRouter } from "express";
import gamesRouter from "./games";
import healthRouter from "./health";
import matchesRouter from "./matches";

const router: IRouter = Router();

router.use(healthRouter);
router.use(gamesRouter);
router.use(matchesRouter);

export default router;
